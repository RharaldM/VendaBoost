// Session Capture Extension - Content Script
// This runs in the context of web pages to extract storage data

(function() {
  'use strict';

  // Listen for messages from the popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getStorage') {
      try {
        const storageData = {
          localStorage: {},
          sessionStorage: {}
        };

        // Capture localStorage if requested
        if (request.getLocalStorage && typeof localStorage !== 'undefined') {
          storageData.localStorage = captureStorage(localStorage);
        }

        // Capture sessionStorage if requested
        if (request.getSessionStorage && typeof sessionStorage !== 'undefined') {
          storageData.sessionStorage = captureStorage(sessionStorage);
        }

        // Send response back to popup
        sendResponse(storageData);
        
      } catch (error) {
        console.error('Storage extraction error:', error);
        sendResponse({
          error: error.message,
          localStorage: {},
          sessionStorage: {}
        });
      }
      
      return true; // Keep message channel open for async response
    }
  });

  // Helper function to safely extract storage data
  function captureStorage(storage) {
    const data = {};
    
    try {
      // Get all keys from storage
      for (let i = 0; i < storage.length; i++) {
        const key = storage.key(i);
        if (key) {
          try {
            const value = storage.getItem(key);
            
            // Try to parse JSON values for better structure
            try {
              const parsed = JSON.parse(value);
              data[key] = {
                type: 'json',
                value: parsed
              };
            } catch {
              // If not JSON, store as string
              data[key] = {
                type: 'string',
                value: value
              };
            }
          } catch (itemError) {
            console.warn(`Failed to get item ${key}:`, itemError);
            data[key] = {
              type: 'error',
              value: null,
              error: itemError.message
            };
          }
        }
      }
    } catch (error) {
      console.error('Storage iteration error:', error);
    }
    
    return data;
  }

  // Optional: Detect and capture authentication tokens from common locations
  // This is disabled by default for security - uncomment if needed
  /*
  function findAuthTokens() {
    const tokens = {};
    
    // Check meta tags
    const metaTags = document.querySelectorAll('meta[name*="token"], meta[name*="csrf"]');
    metaTags.forEach(tag => {
      const name = tag.getAttribute('name');
      const content = tag.getAttribute('content');
      if (content) {
        tokens[`meta_${name}`] = content;
      }
    });
    
    // Check common cookie names (these will be captured via chrome.cookies API)
    // Just noting their presence here
    const cookieNames = document.cookie.split(';').map(c => c.trim().split('=')[0]);
    const authCookies = cookieNames.filter(name => 
      /token|auth|session|jwt/i.test(name)
    );
    
    if (authCookies.length > 0) {
      tokens.detectedAuthCookies = authCookies;
    }
    
    return tokens;
  }
  */

  // Send a ready signal to indicate content script is loaded
  chrome.runtime.sendMessage({ action: 'contentScriptReady' });

})();