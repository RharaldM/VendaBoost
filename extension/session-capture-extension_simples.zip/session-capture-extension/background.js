// Session Capture Extension - Background Service Worker
// Handles cookie management and cross-origin requests

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getCookies') {
    handleGetCookies(request.url, sendResponse);
    return true; // Keep message channel open for async response
  }
  
  if (request.action === 'contentScriptReady') {
    // Content script has loaded successfully
    console.log('Content script ready in tab:', sender.tab?.id);
  }
});

// Get all cookies for a given URL
async function handleGetCookies(url, sendResponse) {
  try {
    const urlObj = new URL(url);
    
    // Get all cookies for the domain
    const cookies = await chrome.cookies.getAll({
      domain: urlObj.hostname
    });
    
    // Also get cookies for parent domain (e.g., .example.com for sub.example.com)
    const domainParts = urlObj.hostname.split('.');
    const parentCookies = [];
    
    if (domainParts.length > 2) {
      // Try parent domain with leading dot
      const parentDomain = `.${domainParts.slice(-2).join('.')}`;
      try {
        const additionalCookies = await chrome.cookies.getAll({
          domain: parentDomain
        });
        parentCookies.push(...additionalCookies);
      } catch (error) {
        console.log('Could not get parent domain cookies:', error);
      }
    }
    
    // Combine and deduplicate cookies
    const allCookies = [...cookies, ...parentCookies];
    const uniqueCookies = Array.from(
      new Map(allCookies.map(cookie => [`${cookie.name}_${cookie.domain}`, cookie])).values()
    );
    
    // Sort cookies by importance (session cookies first)
    uniqueCookies.sort((a, b) => {
      // Prioritize session-related cookies
      const sessionNames = ['session', 'auth', 'token', 'jwt', 'sid'];
      const aIsSession = sessionNames.some(name => a.name.toLowerCase().includes(name));
      const bIsSession = sessionNames.some(name => b.name.toLowerCase().includes(name));
      
      if (aIsSession && !bIsSession) return -1;
      if (!aIsSession && bIsSession) return 1;
      
      // Then sort by httpOnly (more secure cookies first)
      if (a.httpOnly && !b.httpOnly) return -1;
      if (!a.httpOnly && b.httpOnly) return 1;
      
      return 0;
    });
    
    sendResponse({ cookies: uniqueCookies });
    
  } catch (error) {
    console.error('Error getting cookies:', error);
    sendResponse({ cookies: [], error: error.message });
  }
}

// Handle extension installation
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('Session Capture Extension service worker started');
  
  if (details.reason === 'install') {
    console.log('Extension installed successfully');
    
    // Set up periodic cleanup if alarms API is available
    await setupPeriodicCleanup();
    
    // Inject into existing tabs
    await injectIntoExistingTabs();
    
  } else if (details.reason === 'update') {
    console.log('Extension updated to version', chrome.runtime.getManifest().version);
    
    // Inject into existing tabs after update
    await injectIntoExistingTabs();
  }
});

// Optional: Clean up old captures from storage periodically
async function setupPeriodicCleanup() {
  try {
    // Check if alarms API is available
    if (chrome.alarms && chrome.alarms.create) {
      await chrome.alarms.create('cleanupOldCaptures', { periodInMinutes: 1440 }); // Daily
      console.log('Cleanup alarm created successfully');
      
      // Set up alarm listener
      if (chrome.alarms.onAlarm) {
        chrome.alarms.onAlarm.addListener((alarm) => {
          if (alarm.name === 'cleanupOldCaptures') {
            cleanupOldCaptures();
          }
        });
      }
    } else {
      console.log('Alarms API not available - cleanup disabled');
    }
  } catch (error) {
    console.log('Could not set up cleanup alarm:', error);
  }
}

async function cleanupOldCaptures() {
  try {
    const storage = await chrome.storage.local.get(['lastCaptureTime']);
    
    if (storage.lastCaptureTime) {
      const dayInMs = 24 * 60 * 60 * 1000;
      const now = Date.now();
      
      // Remove captures older than 7 days
      if (now - storage.lastCaptureTime > 7 * dayInMs) {
        await chrome.storage.local.remove(['lastCapture', 'lastCaptureTime']);
        console.log('Cleaned up old capture data');
      }
    }
  } catch (error) {
    console.log('Error during cleanup:', error);
  }
}

// Inject content script into already opened tabs when extension is installed/reloaded
async function injectIntoExistingTabs() {
  try {
    // Check if scripting API is available
    if (!chrome.scripting || !chrome.scripting.executeScript) {
      console.log('Scripting API not available');
      return;
    }
    
    // Get all tabs
    const tabs = await chrome.tabs.query({});
    
    // Inject content script into eligible tabs
    for (const tab of tabs) {
      if (tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
          });
          console.log(`Injected content script into tab ${tab.id}`);
        } catch (error) {
          // Ignore errors for tabs where we can't inject (chrome://, etc.)
          console.log(`Could not inject into tab ${tab.id}:`, error.message);
        }
      }
    }
  } catch (error) {
    console.log('Error injecting into existing tabs:', error);
  }
}

// Service worker keep-alive (prevents service worker from being terminated)
let keepAliveInterval;

chrome.runtime.onStartup.addListener(() => {
  console.log('Extension startup');
  startKeepAlive();
});

chrome.runtime.onInstalled.addListener(() => {
  startKeepAlive();
});

function startKeepAlive() {
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
  }
  
  keepAliveInterval = setInterval(() => {
    // Simple operation to keep service worker alive
    chrome.storage.local.get('keepAlive', () => {
      // This prevents the service worker from being terminated
    });
  }, 25000); // Every 25 seconds
}

// Clean up interval on shutdown
chrome.runtime.onSuspend.addListener(() => {
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
  }
});